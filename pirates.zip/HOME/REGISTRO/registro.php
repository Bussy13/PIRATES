<?php

require('../LOGIN/conexion.php');

// Parte de insertar

  if (isset($_POST['enviar'])) {
    $user = $_POST["usuario"];
    $clave = $_POST["contraseña"];
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $sexo = $_POST["sexo"];


    $insertarDatos = "INSERT INTO clientes VALUES('$user', '$clave','$nombre','$correo','$telefono', '$sexo')";

    $ejecutarInsertar = mysqli_query($conn, $insertarDatos);


    echo "<script> alert('Usuario registrado.');window.location= '../LOGIN/login.html'</script>";

    if(!$ejecutarInsertar){

        echo"<script> alert('Usuario ya registrado, por favor intentelo de nuevo.');window.location= 'registro.html' </script>";
    }
}
